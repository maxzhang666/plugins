if (typeof (csdn) != "undefined") {
    csdn.copyright.init("", "", ""); //去除剪贴板劫持
  }