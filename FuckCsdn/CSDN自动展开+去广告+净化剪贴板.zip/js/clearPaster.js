if (typeof (csdn) != "undefined") {
    csdn.copyright.init("", "", ""); //去除剪贴板劫持
  }
$("#check-adblock-time").text(999999999999);
$(".check-adblock-bg").hide();